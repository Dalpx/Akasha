import 'package:flutter/material.dart';

class NotificacionView extends StatelessWidget {
  const NotificacionView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Notificación"),),
    );
  }
}