import 'package:flutter/material.dart';

class ProveedorView extends StatelessWidget {
  const ProveedorView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Proveedor"),),
    );
  }
}