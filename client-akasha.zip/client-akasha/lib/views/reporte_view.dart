import 'package:flutter/material.dart';

class ReporteView extends StatelessWidget {
  const ReporteView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Reporte"),),
    );
  }
}