import 'dart:convert';
import 'dart:developer';

import 'package:http/http.dart' as http;

import '../models/venta.dart';
import '../models/detalle_venta.dart';
import 'inventario_service.dart';


class VentaService {
  /// Lista en memoria con las cabeceras de venta.
  final List<Venta> _ventas = <Venta>[];

  /// Detalles agrupados por número de comprobante.
  final Map<String, List<DetalleVenta>> _detallesPorVenta =
      <String, List<DetalleVenta>>{};

  // Referencia al servicio de inventario para poder actualizar stock.
  final InventarioService _inventarioService;

  final String _ventaUrl =
      "http://localhost/akasha/server-akasha/src/venta";

  VentaService({
    required InventarioService inventarioService,
  }) : _inventarioService = inventarioService;

  /// Registra una venta con sus detalles.
  Future<Venta> registrarVenta(
    Venta venta,
    List<DetalleVenta> detalles,
  ) async {
    // Simula una operación asíncrona (llamada a API, BD, etc.)
    await Future.delayed(const Duration(milliseconds: 300));

    // Guardar cabecera
    _ventas.add(venta);

    // Guardar detalles asociados al número de comprobante
    _detallesPorVenta[venta.nroComprobante] =
        List<DetalleVenta>.from(detalles);

    // Actualizar stock en inventario según los detalles de la venta.
    for (final DetalleVenta detalle in detalles) {
      final String ubicacion = detalle.idUbicacion.trim();

      // Como idUbicacion ya no es nullable, usamos string vacío como "sin ubicación"
      if (ubicacion.isNotEmpty) {
        await _inventarioService.disminuirStockEnUbicacion(
          detalle.idProducto,
          ubicacion,
          detalle.cantidad,
        );
      } else {
        await _inventarioService.disminuirStock(
          detalle.idProducto,
          detalle.cantidad,
        );
      }
    }

    return venta;
  }

  /// Devuelve todas las ventas registradas.
  Future<List<Venta>> obtenerVentas() async {
    final url = Uri.parse(_ventaUrl);
    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        log(response.body);
        final List<dynamic> jsonVenta = jsonDecode(response.body);

        //Convertimos a lista de venta
        final List<Venta> ventas = jsonVenta
            .map(
              (venta) => Venta.fromJson(venta as Map<String, dynamic>),
            )
            .toList();

        return ventas;
      } else {
        log("Fallo el codigo: ${response.statusCode}");
        return [];
      }
    } catch (e) {
      log("El error fue en ObtenerVentas: ${e}");
      return [];
    }
  }

  /// Devuelve todos los detalles de una venta específica,
  /// usando el número de comprobante como identificador.
  Future<List<DetalleVenta>> obtenerDetallesPorVenta(
    String nroComprobante,
  ) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return _detallesPorVenta[nroComprobante] ?? <DetalleVenta>[];
  }
}
