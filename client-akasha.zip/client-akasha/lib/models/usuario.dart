class Usuario {
  final String username;
  final String password;
  final String rol;

  Usuario({required this.username, required this.password, required this.rol});


}