/// Representa una línea (detalle) dentro de una venta o factura.
class DetalleVenta {
  int idProducto;
  int cantidad;
  double precioUnitario;
  double subtotal;
  String idUbicacion; // ubicación desde donde sale el producto

  DetalleVenta({
    required this.idProducto,
    required this.cantidad,
    required this.precioUnitario,
    required this.subtotal,
    required this.idUbicacion,
  });

  /// Crea una instancia de DetalleVenta desde un mapa JSON.
  factory DetalleVenta.fromJson(Map<String, dynamic> json) {
    return DetalleVenta(
      idProducto: json['id_producto'] as int,
      cantidad: json['cantidad'] as int,
      precioUnitario: (json['precio_unitario'] as num).toDouble(),
      subtotal: (json['subtotal'] as num).toDouble(),
      idUbicacion: json['id_ubicacion'] as String,
    );
  }

  /// Convierte el objeto DetalleVenta a un mapa JSON.
  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id_producto': idProducto,
      'cantidad': cantidad,
      'precio_unitario': precioUnitario,
      'subtotal': subtotal,
      'id_ubicacion': idUbicacion,
    };
  }
}
