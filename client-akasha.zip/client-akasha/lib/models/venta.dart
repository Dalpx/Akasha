/// Representa la cabecera de una venta o factura.
class Venta {
  String nroComprobante;
  String idTipoComprobante;
  String idCliente;
  String idUsuario;
  double subtotal;
  double impuesto;
  double total;
  String estado;

  Venta({
    required this.nroComprobante,
    required this.idTipoComprobante,
    required this.idCliente,
    required this.idUsuario,
    required this.subtotal,
    required this.impuesto,
    required this.total,
    required this.estado,

  });

  /// Crea una instancia de Venta desde un mapa JSON.
  factory Venta.fromJson(Map<String, dynamic> json) {
    return Venta(
      nroComprobante: json['nro_comprobante'] as String,
      idTipoComprobante: json['id_tipo_comprobante'] as String,
      idCliente: json['id_cliente'] as String,
      idUsuario: json['id_usuario'] as String,
      subtotal: (json['subtotal'] as num).toDouble(),
      impuesto: (json['impuesto'] as num).toDouble(),
      total: (json['total'] as num).toDouble(),
      estado:json['estado'] as String,
    );
  }

  /// Convierte el objeto Venta a un mapa JSON.
  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'nro_comprobante': nroComprobante,
      'id_tipo_comprobante': idTipoComprobante,
      'id_cliente': idCliente,
      'id_usuario': idUsuario,
      'subtotal': subtotal,
      'impuesto': impuesto,
      'total': total,
      'estado': estado,
    };
  }
}
