package com.example.akasha

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
